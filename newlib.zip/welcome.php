<html>
<body>


Welcome 

<?php $conn = new mysqli("localhost", "root", "Test@1234");
$db=mysqli_select_db($conn,"geekdatas");
?>



</body>
</html>