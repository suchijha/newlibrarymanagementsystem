<?php
$a=(int)readLine('enter int');
$b=(int)readLine('enter int');
$c=(int)readLine('enter int');
$sum=$a+$b+$c;
echo"sum:",$sum;
?>
